import React, { useEffect, useState } from "react";
import api from "../api";
import "../styles.css";

export default function AssignmentDetail({ assignment, user, onBack }) {
  const [submissions, setSubmissions] = useState([]);
  const [files, setFiles] = useState([]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    load();
    // eslint-disable-next-line
  }, []);

  const load = async () => {
    const res = await api.get(`/submissions/${assignment.id}`);
    setSubmissions(res.data || []);
  };

  const mySub = submissions.find((s) => s.student_id === user.id);

  const submit = async () => {
    if (!files.length) return alert("เลือกไฟล์ก่อน");
    const fd = new FormData();
    fd.append("student_id", user.id);
    files.forEach((f) => fd.append("files", f));
    await api.post(`/submissions/${assignment.id}`, fd);
    setMsg("ส่งงานแล้ว 🎉");
    load();
  };

  return (
    <div>
      <button onClick={onBack}>← กลับ</button>
      <h1>{assignment.title}</h1>
      <p>{assignment.description}</p>

      {/* STUDENT */}
      {user.role === "student" && (
        <div className="card">
          <h3>📤 ส่งงาน</h3>
          <input type="file" multiple onChange={(e) => setFiles([...e.target.files])} />
          <button onClick={submit}>ส่งงาน</button>
          {msg && <p>{msg}</p>}
          {mySub && <p>✓ คุณส่งงานแล้ว</p>}
        </div>
      )}

      {/* TEACHER */}
      {user.role === "teacher" && (
        <div className="card">
          <h3>รายชื่อนักเรียนที่ส่ง</h3>
          {submissions.map((s) => (
            <div key={s.id}>
              {s.student_name} — คะแนน {s.grade ?? "-"}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
